<?php
session_start();
include 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - Sistem Pendaftaran Sekolah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f1f5f9;
            color: #0f172a;
        }
        .navbar {
            background: #38bdf8;
            color: #fff;
            border-bottom: none;
            min-height: 56px;
            box-shadow: 0 2px 8px rgba(6,182,212,0.06);
        }
        .navbar-brand {
            color: #fff !important;
            font-weight: 600;
            letter-spacing: 1px;
        }
        .navbar .nav-link, .navbar .dropdown-toggle {
            color: #fff !important;
        }
        .sidebar {
            background: #fff;
            min-height: calc(100vh - 56px);
            box-shadow: 2px 0 10px rgba(6,182,212,0.06);
        }
        .sidebar .nav-link {
            color: #06b6d4;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e0f2fe;
            border-radius: 0 30px 30px 0;
            margin: 0.2rem 0;
            font-weight: 500;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .nav-link:hover {
            background-color: #e0f2fe;
            color: #38bdf8;
            transform: translateX(5px);
        }
        .sidebar .nav-link.active {
            background-color: #06b6d4;
            color: #fff;
        }
        .main-content {
            padding: 2rem;
        }
        h2, h5 {
            color: #06b6d4;
            font-weight: 600;
        }
        .text-muted {
            color: #64748b !important;
        }
        .btn, .btn-action {
            background: #38bdf8;
            color: #fff;
            border: none;
            border-radius: 8px;
            transition: background 0.2s, color 0.2s;
        }
        .btn-warning {
            background: #facc15;
            color: #0f172a;
        }
        .btn-warning:hover {
            background: #f59e42;
            color: #fff;
        }
        .btn-danger {
            background: #ef4444;
            color: #fff;
        }
        .btn-danger:hover {
            background: #b91c1c;
            color: #fff;
        }
        .btn:hover, .btn-action:hover {
            background: #06b6d4;
            color: #fff;
        }
        .dropdown-menu {
            border-radius: 10px;
            border: 1px solid #e0f2fe;
        }
        .table-container {
            background: #fff;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(6,182,212,0.08);
        }
        .table th {
            background: #e0f2fe;
            color: #0f172a;
        }
        .table td {
            color: #0f172a;
        }
        .badge.bg-primary {
            background: #06b6d4 !important;
            color: #fff !important;
            font-weight: 500;
        }
        .badge.bg-danger {
            background: #ef4444 !important;
            color: #fff !important;
            font-weight: 500;
        }
        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-graduation-cap"></i> Sistem Pendaftaran Sekolah
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user"></i> <?= $user_name ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar">
                    <nav class="nav flex-column">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a class="nav-link active" href="siswa.php">
                            <i class="fas fa-users"></i> Data Siswa
                        </a>
                        <a class="nav-link" href="tambah.php">
                            <i class="fas fa-user-plus"></i> Tambah Siswa
                        </a>
                        <?php if ($user_role == 'admin'): ?>
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-user-cog"></i> Kelola User
                        </a>
                        <?php endif; ?>
                    </nav>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10">
                <div class="main-content">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><i class="fas fa-users"></i> Data Siswa</h2>
                        <a href="tambah.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah Siswa
                        </a>
                    </div>

                    <!-- Data Table -->
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Tanggal Daftar</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $result = mysqli_query($conn, "SELECT * FROM siswa ORDER BY created_at DESC");
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>
                                            <td>$no</td>
                                            <td><strong>{$row['nama']}</strong></td>
                                            <td>{$row['alamat']}</td>
                                            <td>
                                                <span class='badge " . ($row['jenis_kelamin'] == 'L' ? 'bg-primary' : 'bg-danger') . "'>
                                                    <i class='fas " . ($row['jenis_kelamin'] == 'L' ? 'fa-male' : 'fa-female') . "'></i>
                                                    " . ($row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan') . "
                                                </span>
                                            </td>
                                            <td>" . date('d/m/Y', strtotime($row['tanggal_lahir'])) . "</td>
                                            <td>" . date('d/m/Y H:i', strtotime($row['created_at'])) . "</td>
                                            <td>
                                                <a href='edit.php?id={$row['id']}' class='btn btn-warning btn-action' title='Edit'>
                                                    <i class='fas fa-edit'></i>
                                                </a>
                                                <a href='hapus.php?id={$row['id']}' onclick='return confirm(\"Yakin ingin menghapus data {$row['nama']}?\")' class='btn btn-danger btn-action' title='Hapus'>
                                                    <i class='fas fa-trash'></i>
                                                </a>
                                            </td>
                                        </tr>";
                                        $no++;
                                    }
                                    
                                    if ($no == 1) {
                                        echo "<tr><td colspan='7' class='text-center text-muted'>Belum ada data siswa</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 