<?php
// Redirect ke halaman login
header('Location: login.php');
exit();
?>
