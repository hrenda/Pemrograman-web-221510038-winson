<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "form_db";

// Create database connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Retrieve form data
// Using mysqli_real_escape_string to prevent SQL injection
$nama = $conn->real_escape_string($_POST['nama']);
$email = $conn->real_escape_string($_POST['email']);
$umur = (int)$_POST['umur']; // Cast to integer as it's a number
$pesan = $conn->real_escape_string($_POST['pesan']);

// SQL to insert data into the 'kontak' table, including the new 'umur' column
$sql = "INSERT INTO kontak (nama, email, umur, pesan) VALUES ('$nama', '$email', $umur, '$pesan')";

if ($conn->query($sql) === TRUE) {
    echo "Data berhasil dikirim!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>